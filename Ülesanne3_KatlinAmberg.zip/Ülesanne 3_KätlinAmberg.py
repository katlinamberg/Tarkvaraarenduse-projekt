import pygame  # Pygame import, mis võimaldab mängu kasutuse
import sys  # Sys import, mis võimaldab süsteemi funktsioone
import random  # Random import juhuslike arvude genereerimiseks

pygame.init()  # Pygame mängu alustamine

# Mängu seaded
ekraani_laius, ekraani_korgus = 640, 480  # Seadistab mängu akna suuruse
ekraan = pygame.display.set_mode((ekraani_laius, ekraani_korgus))  # Loob mänguakna
pygame.display.set_caption("Autode Mäng")  # Seab mänguakna pealkirja

# Laadime taustapildi
taust = pygame.image.load("bg_rally.jpg")  # Laeb taustapildi failist
taust = pygame.transform.scale(taust, (ekraani_laius, ekraani_korgus))  # Kohandab tausta suurust vastavalt ekraanile

# Laadime autode pildid
punane_auto = pygame.image.load("f1_red.png")  # Laeb punase auto pildi failist
punane_auto = pygame.transform.scale(punane_auto, (50, 80))  # Kohandab punase auto suurust
sinine_auto = pygame.image.load("f1_blue.png")  # Laeb sinise auto pildi failist
sinine_auto = pygame.transform.scale(sinine_auto, (50, 80))  # Kohandab sinise auto suurust

# Tee asukoht
tee_x = 250  # Tee alguspunkt x-koordinaat
tee_laius = 140  # Tee laius

# Autode algusasukohad
punane_auto_x = tee_x + (tee_laius // 2) - 25  # Punase auto alguspunkt x-koordinaat
punane_auto_y = ekraani_korgus - 100  # Punase auto alguspunkt y-koordinaat

sinine_auto_x = random.randint(tee_x, tee_x + tee_laius - 50)  # Sinise auto alguspunkt x-koordinaat
sinine_auto_y = -80  # Sinise auto alguspunkt y-koordinaat

# Autode kiirus
punane_auto_kiirus = 4  # Punase auto kiirus pikslites sekundis
sinine_auto_kiirus = ekraani_laius / 640.0  # Sinise auto kiirus vastavalt ekraani laiusele

# Mängu skoor
global skoor  # Määrab skoori globaalse muutujana
skoor = 0  # Skoori algväärtus
skoor_font = pygame.font.SysFont("Arial", 24)  # Määrab skoori fonti ja suuruse

# Sprite klassid punase ja sinise auto jaoks
class PunaneAuto(pygame.sprite.Sprite):  # Punase auto sprite klass
    def __init__(self):  # Konstruktor
        super().__init__()  # Klassi Sprite konstruktor
        self.image = punane_auto  # Määrab sprite pildi punase auto pildiks
        self.rect = self.image.get_rect(topleft=(punane_auto_x, punane_auto_y))  # Määrab sprite'i asukoha

    def update(self):  # Meetod sprite'i uuendamiseks
        nupud = pygame.key.get_pressed()  # Võtab vajutatud nupud
        if nupud[pygame.K_LEFT]:  # Kui vajutati vasakule nuppu
            if self.rect.x - punane_auto_kiirus >= tee_x:  # Kontrollib, kas auto liigub tee piiridest välja
                self.rect.x -= punane_auto_kiirus  # Liigutab autot vasakule
        if nupud[pygame.K_RIGHT]:  # Kui vajutati paremale nuppu
            if self.rect.x + 50 + punane_auto_kiirus <= tee_x + tee_laius:  # Kontrollib, kas auto liigub tee piiridest välja
                self.rect.x += punane_auto_kiirus  # Liigutab autot paremale

class SinineAuto(pygame.sprite.Sprite):  # Sinise auto sprite klass
    def __init__(self):  # Konstruktor
        super().__init__()  # Klassi Sprite konstruktor
        self.image = sinine_auto  # Määrab sprite pildi sinise auto pildiks
        self.rect = self.image.get_rect(topleft=(sinine_auto_x, sinine_auto_y))  # Määrab sprite'i asukoha

    def update(self):  # Meetod sprite'i uuendamiseks
        global skoor  # Kasutab skoori globaalset muutujat
        self.rect.y += sinine_auto_kiirus  # Liigutab sinist autot alla
        if self.rect.y > ekraani_korgus:  # Kui sinine auto jõuab ekraani alla
            self.rect.y = -80  # Paneb sinise auto alguspunkti ülemisele ekraanile
            self.rect.x = random.randint(tee_x, tee_x + tee_laius - 50)  # Määrab uue x-koordinaadi
            if self.rect.y >= sinine_auto_sprite.rect.y:  # Kontrollib, kas punane auto on möödunud
                skoor += 1  # Suurendab skoori
        elif pygame.sprite.collide_rect(punane_auto_sprite, sinine_auto_sprite):  # Kui punane ja sinine auto kolid
            skoor -= 1  # Vähendab skoori

# Sprite rühm
autod = pygame.sprite.Group()  # Loob sprite rühma
punane_auto_sprite = PunaneAuto()  # Loob punase auto sprite'i
sinine_auto_sprite = SinineAuto()  # Loob sinise auto sprite'i
autod.add(punane_auto_sprite, sinine_auto_sprite)  # Lisab sprite'id sprite rühma

# Mängutsükkel
jookseb = True  # Muutuja, mis hoiab mängutsüklit käimas
while jookseb:  # Mängutsükkel
    for sündmus in pygame.event.get():  # Käib läbi pygame'i sündmused
        if sündmus.type == pygame.QUIT:  # Kui kasutaja vajutab sulgemisnuppu
            jookseb = False  # Lõpetab mängu

    # Joonistame taustapildi ja tee
    ekraan.blit(taust, (0, 0))  # Joonistab tausta ekraanile
    pygame.draw.rect(ekraan, (100, 100, 100), (tee_x, 0, tee_laius, ekraani_korgus))  # Joonistab tee

    # Uuendame ja joonistame autod
    autod.update()  # Uuendab autode asukohta ja olekut
    autod.draw(ekraan)  # Joonistab autod ekraanile

    # Kuva skoor ekraani ülaosas
    skoor_tekst = skoor_font.render("Skoor: " + str(skoor), True, (255, 255, 255))  # Loob skoori teksti
    ekraan.blit(skoor_tekst, (10, 10))  # Joonistab skoori ekraanile

    pygame.display.flip()  # Uuendab ekraani

# Lõpetamine
pygame.quit()  # Lõpetab pygame'i
sys.exit()  # Lõpetab programmi täitmise
