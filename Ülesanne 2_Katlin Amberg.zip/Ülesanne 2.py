import pygame #Pygame import, mis võimaldab mängude ja graafika kasutuse
import sys #Sys import, mis võimaldab funktsioonid

pygame.init() #Pygame alustamine, et saaksime selle funktsioone kasutada

# Ekraani seadistus
ekraani_laius, ekraani_korgus = 640, 480 #Ekraani laiuse ja kõrguse määramine
ekraan = pygame.display.set_mode([ekraani_laius, ekraani_korgus]) #Ekraani loomine
pygame.display.set_caption("Ülesanne 2") #Ekraani pealkirja määramine

# Piltide laadimine
taust = pygame.image.load("bg_shop.png") #Tausta pilfifaili laadimine
poemyyja = pygame.image.load("seller.png") #Poemüüja pildifaili laadimine
poemyyja = pygame.transform.scale(poemyyja, (255, 310)) #Poemüüja asukoha määramine
jutumull = pygame.image.load("chat.png") #Jutumulli pildifaili määramine
jutumull = pygame.transform.scale(jutumull, (255, 200)) #Jutumulli asukoha määramine

# Jutumulli tekst
font = pygame.font.SysFont("tahoma", 16)  # Fonti määramine: Tahoma
tekst = "Tere, olen Kätlin Amberg" #Jutumulli teksti määramine
tekst_pildina = font.render(tekst, True, (255, 255, 255)) #Jutumulli teksti värvuse määramine fondiga

# Mängutsükkel
jookseb = True #Muutuja ''jookseb'', mis näitab kas mäng töötab või mitte
while jookseb: #Tsüklise kestvus
    for sündmus in pygame.event.get(): #Kõikide sündmuste läbikäimine
        if sündmus.type == pygame.QUIT: #QUIT, akna sulgemise määramine
            jookseb = False #Tsükli lõpetamine

    ekraan.blit(taust, (0, 0)) #Tausta pildifaili ekraanile joonistamine
    poemyyja_koord = (100, 150) #Poemüüja pildifaili koordinaatide määramine
    ekraan.blit(poemyyja, poemyyja_koord) #Pildifaili poemüüja joonistamine ekraanile

    x_koord_jutumull = 250  # Jutumulli pildifaili X koordinaadi määramine
    y_koord_jutumull = 60  # Jutumulli pildifaaili Y koordinaadi määramine
    ekraan.blit(jutumull, (x_koord_jutumull, y_koord_jutumull)) #Pildifaili jutumull joonistamine ekraanile

    tekst_laius, tekst_korgus = font.size(tekst) #Mõõdame tekstile laiuse ja kõrguse
    x_koord_tekst = x_koord_jutumull + (jutumull.get_width() - tekst_laius) // 2 #Arvutame tekstile X-koordinaadi
    y_koord_tekst = y_koord_jutumull + (jutumull.get_height() - tekst_korgus) // 2 #Arvutamie tekstile Y-koordinaadi
    ekraan.blit(tekst_pildina, (x_koord_tekst, y_koord_tekst))

    pygame.display.flip() #Värskendame ekraani, et joonistused ilmuksid

# Lõpetamine
pygame.quit()
sys.exit()
